from Map import map
from SearchAlgorithms import searchalgorithms
from Output import output

def get_input():
    """Get input from the user."""
    n = int(input())
    matrix = []
    for _ in range(n):
        row = input().split()
        matrix.append(row)
    return n, matrix

# Get input
n, matrix = get_input()

# Create instances of Map, SearchAlgorithms, and Output classes
map_obj = map(n, matrix)
search_obj = searchalgorithms(map_obj)
output_obj = output()

# Solve and print output for each scenario
path1, coins1, damage1 = search_obj.bfs()
output_obj.print_result(path1, coins1, damage1, 1, matrix)

path2, coins2, damage2 = search_obj.a_star(maximize_coins=True)
output_obj.print_result(path2, coins2, damage2, 2, matrix)

path3, coins3, damage3 = search_obj.a_star(maximize_coins=False)
output_obj.print_result(path3, coins3, damage3, 3, matrix)