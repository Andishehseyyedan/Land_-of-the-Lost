class output:
    """Class for outputting results."""

    def print_result(self, path, coins, damage, scenario, matrix):
        """Print the result of the search."""
        if path:
            print(f"Path for scenario {scenario}:")
            for i, (row, col) in enumerate(path):
                if i == 0:
                    print(f"Initially, Arian starts with {coins} coins.")
                else:
                    if row > path[i - 1][0]:
                        direction = "down"
                    else:
                        direction = "right"
                    print(f"{direction} ({matrix[row][col]})")
            print(f"Finally, Arian has {coins} coins and suffered {damage} damage.")
        else:
            print(f"No path found for scenario {scenario}.")