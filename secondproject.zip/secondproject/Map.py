class map:
    """Class representing the map of the land."""

    def __init__(self, n, matrix):
        """Initialize the map with size and matrix."""
        self.n = n
        self.matrix = matrix

    def get_value(self, row, col):
        """Get the value of a cell at the given position."""
        return self.matrix[row][col]

    def is_valid_move(self, row, col):
        """Check if a move to the given position is valid."""
        return 0 <= row < self.n and 0 <= col < self.n