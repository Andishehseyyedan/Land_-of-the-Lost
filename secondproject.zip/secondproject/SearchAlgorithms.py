class searchalgorithms:
    """Class for search algorithms."""

    def __init__(self, map_obj):
        """Initialize the search algorithms with a map object."""
        self.map = map_obj

    def bfs(self):
        """Breadth-first search (BFS) algorithm to find the path."""
        start = (0, 0)
        end = (self.map.n - 1, self.map.n - 1)
        queue = [(start, [start], int(self.map.get_value(0, 0)), 0, False)]  # (position, path, coins, damage, thief)
        visited = {start}

        while queue:
            (row, col), path, coins, damage, has_thief = queue.pop(0)

            if (row, col) == end:
                return path, coins, damage

            moves = [(row + 1, col), (row, col + 1)]
            for next_row, next_col in moves:
                if self.map.is_valid_move(next_row, next_col) and (next_row, next_col) not in visited:
                    next_val = self.map.get_value(next_row, next_col)
                    next_coins = coins
                    next_damage = damage
                    next_has_thief = has_thief

                    if next_val == '!':
                        if has_thief:
                            next_has_thief = False
                        else:
                            next_has_thief = True
                    else:
                        next_val = int(next_val)
                        if has_thief:
                            if next_val > 0:
                                next_damage += next_val
                            else:
                                next_damage -= next_val
                            next_has_thief = False
                        else:
                            next_coins += next_val

                    queue.append(((next_row, next_col), path + [(next_row, next_col)], next_coins, next_damage, next_has_thief))
                    visited.add((next_row, next_col))
        return path, coins, damage

    def a_star(self, maximize_coins=True):
        """A* search algorithm to find the path with maximum coins or minimum damage."""
        start = (0, 0)
        end = (self.map.n - 1, self.map.n - 1)
        priority_queue = [(0, start, [start], int(self.map.get_value(0, 0)), 0, False)]  # (priority, position, path, coins, damage, thief)
        visited = {start}

        def heuristic(row, col):
            """Heuristic function."""
            return abs(end[0] - row) + abs(end[1] - col)

        while priority_queue:
            # Find the element with the lowest priority
            min_priority = float('inf')
            min_index = -1
            for i, (priority, _, _, _, _, _) in enumerate(priority_queue):
                if priority < min_priority:
                    min_priority = priority
                    min_index = i
            priority, (row, col), path, coins, damage, has_thief = priority_queue.pop(min_index)

            if (row, col) == end:
                return path, coins, damage

            if (row, col) in visited:
                continue

            visited.add((row, col))

            moves = [(row + 1, col), (row, col + 1)]
            for next_row, next_col in moves:
                if self.map.is_valid_move(next_row, next_col):
                    next_val = self.map.get_value(next_row, next_col)
                    next_coins = coins
                    next_damage = damage
                    next_has_thief = has_thief

                    if next_val == '!':
                        if has_thief:
                            next_has_thief = False
                        else:
                            next_has_thief = True
                    else:
                        next_val = int(next_val)
                        if has_thief:
                            if next_val > 0:
                                next_damage += next_val
                            else:
                                next_damage -= next_val
                            next_has_thief = False
                        else:
                            next_coins += next_val

                    if maximize_coins:
                        priority = -next_coins + heuristic(next_row, next_col)  # maximize coins
                    else:
                        priority = damage + heuristic(next_row, next_col)  # minimize damage

                    priority_queue.append((priority, (next_row, next_col), path + [(next_row, next_col)], next_coins, next_damage, next_has_thief))
        return path, coins, damage